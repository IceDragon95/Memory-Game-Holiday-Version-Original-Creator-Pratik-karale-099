# memory-game
# test your memory now



Things i learnt while building the project:
+ learnt to use event-listeners
+ Durstenfeld algorthim of shuffling an array
+ usage of timeOut and timeInterval functions
+ A lot about DOM techniques

***Changes by 氷𝐼𝒸𝑒𝒟𝓇𝒶𝑔𝑜𝓃氷#9393**

- Holiday edition
- New Emoji's

Thank you, Pat.
